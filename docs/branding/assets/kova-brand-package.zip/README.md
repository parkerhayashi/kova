# Kova Brand Package

Complete logo files for Kova in every format you'll need across digital and print.

## Two forms, used separately

The Kova brand exists as **two interchangeable forms**: the **Mark** (the K) and the **Wordmark** ("Kova"). They are not used together — the K of the wordmark IS the mark, so pairing them creates two Ks in a row. Choose one form per surface:

- **The Mark** → app icons, favicons, social avatars, watermarks, anywhere too tight for the full wordmark
- **The Wordmark** → headers, marketing, website nav, print, packaging — anywhere the brand name needs to be read

---

## File formats — what to use when

| Format | Use for | Notes |
|---|---|---|
| **SVG** | Websites, apps, anything digital that supports it. This is your **master** | Infinite resolution, tiny file size |
| **PNG (transparent)** | Slide decks, Instagram, email signatures, docs | When SVG isn't accepted |
| **PDF** | Print vendors — business cards, merch, signage | Hand the brand guidelines PDF to any designer or printer |
| **ICO** | Website favicon | Multi-resolution: 16/32/48/64 px |

---

## Folder structure

### `/svg/` — Master vector files (8 files)
Source of truth. Use these everywhere possible.

**Mark only** (the K with leaf):
- `kova-mark-black.svg`
- `kova-mark-white.svg`

**Wordmark only** ("Kova" custom letterforms):
- `kova-wordmark-black.svg`
- `kova-wordmark-white.svg`

**App icon** (mark inside rounded square):
- `kova-icon-black-bg.svg` — **Primary** (matches source)
- `kova-icon-white-bg.svg` — alternate (light surfaces)
- `kova-icon-outline-black.svg` / `-outline-white.svg` — outlined rounded square, no fill (matches the subtle outlined style of the source)

### `/png/` — Raster exports (28 files)
PNG fallbacks at multiple sizes. All with transparent backgrounds where applicable.

- Marks: 512 / 1024 / 2048 px
- Wordmarks: 800 / 1600 / 3200 px wide
- Icons: 256 / 512 / 1024 / 2048 px (square)

### `/app-icons/` — Ready-to-ship app icons
iOS and Android sizes from the primary black-background icon.
- `app-icon-1024.png` — App Store / Play Store submission
- `app-icon-180.png` — iPhone
- `app-icon-167.png` — iPad Pro
- plus 76, 87, 120, 152, 20, 29, 40, 58, 60, 80
- `android-foreground-432.png` — Android adaptive icon foreground layer (white mark on transparent; pair with a black background layer)

### `/favicon/` — Website favicons
- `favicon.ico` — drop in your site root
- `favicon-16.png` through `favicon-180.png`
- `apple-touch-icon.png` — iOS home screen

### `Kova_Brand_Guidelines.pdf`
7-page brand guide. Share with any designer, printer, or collaborator.

---

## Brand specs

### Color
Monochromatic system — black and white only, with neutrals for hierarchy.

**Kova Black**
- HEX: `#000000` · RGB: `0, 0, 0` · CMYK: `0, 0, 0, 100` · Pantone: `Black 6 C`

**Kova White**
- HEX: `#FFFFFF`

### Wordmark
"Kova" is **custom-drawn** — not a standard typeface. Never re-set it in another font. Always use the vector wordmark files directly.

### Supporting typeface
For UI, headings, body — pair with **Inter** (free): https://rsms.me/inter
- Headings: Inter Bold
- Subheadings, UI labels: Inter SemiBold
- Body: Inter Regular

### Clear space
Padding equal to half the mark's height on all sides.

### Minimum size
- Digital: 24 px (mark)
- Print: 0.25 in (mark)
